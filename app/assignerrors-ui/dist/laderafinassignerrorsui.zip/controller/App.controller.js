sap.ui.define(["sap/ui/core/mvc/Controller"],r=>{"use strict";return r.extend("ladera.fin.assignerrorsui.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map